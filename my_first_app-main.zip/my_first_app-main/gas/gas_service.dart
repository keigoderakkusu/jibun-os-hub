// ============================================================
// Flutter → GAS へのデータ送信サンプル
// ファイル: lib/services/gas_service.dart
// ============================================================

import 'dart:convert';
import 'package:http/http.dart' as http;

class GasService {
  // ← デプロイ後のWebアプリURLに差し替える
  static const String _gasUrl =
      'https://script.google.com/macros/s/AKfycbx-0EPpnFl2jl3vPp1UuAxZo83KK1ucobp1ywymmsjwnK4e1Vl68fcIqS_H-NKPANAU/exec';

  /// 音声テキストをGASに送信して日報を生成・保存する
  static Future<GasResult> sendVoiceReport(String voiceText) async {
    try {
      final response = await http
          .post(
            Uri.parse(_gasUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'text': voiceText,
              'timestamp': DateTime.now().toIso8601String(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          return GasResult.success(ReportData.fromJson(data['data']));
        } else {
          return GasResult.failure(data['error'] ?? '不明なエラー');
        }
      } else {
        return GasResult.failure('HTTPエラー: ${response.statusCode}');
      }
    } catch (e) {
      return GasResult.failure('通信エラー: $e');
    }
  }
}

// ===== 結果モデル =====
class GasResult {
  final bool success;
  final ReportData? data;
  final String? error;

  GasResult._({required this.success, this.data, this.error});

  factory GasResult.success(ReportData data) =>
      GasResult._(success: true, data: data);

  factory GasResult.failure(String error) =>
      GasResult._(success: false, error: error);
}

// ===== 日報データモデル =====
class ReportData {
  final String title;
  final String meetingPartner;
  final String date;
  final String location;
  final String summary;
  final List<String> decisions;
  final List<String> concerns;
  final List<NextAction> nextActions;
  final String memo;

  ReportData({
    required this.title,
    required this.meetingPartner,
    required this.date,
    required this.location,
    required this.summary,
    required this.decisions,
    required this.concerns,
    required this.nextActions,
    required this.memo,
  });

  factory ReportData.fromJson(Map<String, dynamic> json) => ReportData(
        title: json['title'] ?? '',
        meetingPartner: json['meeting_partner'] ?? '',
        date: json['date'] ?? '',
        location: json['location'] ?? '',
        summary: json['summary'] ?? '',
        decisions: List<String>.from(json['decisions'] ?? []),
        concerns: List<String>.from(json['concerns'] ?? []),
        nextActions: (json['next_actions'] as List? ?? [])
            .map((a) => NextAction.fromJson(a))
            .toList(),
        memo: json['memo'] ?? '',
      );
}

class NextAction {
  final String action;
  final String owner;
  final String deadline;

  NextAction(
      {required this.action, required this.owner, required this.deadline});

  factory NextAction.fromJson(Map<String, dynamic> json) => NextAction(
        action: json['action'] ?? '',
        owner: json['owner'] ?? '',
        deadline: json['deadline'] ?? '',
      );
}

// ============================================================
// 使用例 (Flutter Widget内からの呼び出し方)
// ============================================================
// 
// ```dart
// void _submitReport() async {
//   setState(() => _isSending = true);
//
//   final result = await GasService.sendVoiceReport(_recognizedText);
//
//   if (result.success) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text('日報を送信しました: ${result.data!.title}')),
//     );
//   } else {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text('エラー: ${result.error}')),
//     );
//   }
//
//   setState(() => _isSending = false);
// }
// ```
