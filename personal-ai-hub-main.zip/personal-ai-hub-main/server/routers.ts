import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  saveConversation,
  getUserConversations,
  saveEvent,
  getUserEvents,
  saveCareerGoal,
  saveBlogArticle,
  getUserSettings,
  saveUserSettings,
  saveGoal,
  getLatestAiResources,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // チャット・会話管理
  conversations: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserConversations(ctx.user.id)
    ),
    save: protectedProcedure
      .input(
        z.object({
          role: z.enum(["assistant", "secretary", "career", "research"]),
          title: z.string(),
          messages: z.array(z.any()),
        })
      )
      .mutation(({ ctx, input }) =>
        saveConversation(ctx.user.id, input.role, input.title, input.messages)
      ),
  }),

  // 予定・イベント管理
  events: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserEvents(ctx.user.id)
    ),
    save: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          startTime: z.date(),
          description: z.string().optional(),
          endTime: z.date().optional(),
          location: z.string().optional(),
          type: z.enum(["meeting", "date", "travel", "task", "other"]).optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        saveEvent(
          ctx.user.id,
          input.title,
          input.startTime,
          input.description,
          input.endTime,
          input.location,
          input.type
        )
      ),
  }),

  // キャリア目標管理
  careerGoals: router({
    save: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          description: z.string().optional(),
          targetDate: z.date().optional(),
          roadmap: z.array(z.any()).optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        saveCareerGoal(
          ctx.user.id,
          input.title,
          input.description,
          input.targetDate,
          input.roadmap
        )
      ),
  }),

  // ブログ記事管理
  blog: router({
    save: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          content: z.string().optional(),
          prompt: z.string().optional(),
          imageUrl: z.string().optional(),
          status: z.enum(["draft", "published", "archived"]).optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        saveBlogArticle(
          ctx.user.id,
          input.title,
          input.content,
          input.prompt,
          input.imageUrl,
          input.status
        )
      ),
  }),

  // ユーザー設定
  settings: router({
    get: protectedProcedure.query(({ ctx }) =>
      getUserSettings(ctx.user.id)
    ),
    save: protectedProcedure
      .input(
        z.object({
          llmApiUrl: z.string().optional(),
          llmApiKey: z.string().optional(),
          defaultRole: z.enum(["assistant", "secretary", "career", "research"]).optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        saveUserSettings(
          ctx.user.id,
          input.llmApiUrl,
          input.llmApiKey,
          input.defaultRole
        )
      ),
  }),

  // AI リソース・ニュース
  aiResources: router({
    latest: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(({ input }) => getLatestAiResources(input.limit)),
  }),

  // 目標達成ツール
  goals: router({
    save: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          description: z.string().optional(),
          category: z.string().optional(),
          targetDate: z.date().optional(),
          priority: z.enum(["low", "medium", "high"]).optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        saveGoal(
          ctx.user.id,
          input.title,
          input.description,
          input.category,
          input.targetDate,
          input.priority
        )
      ),
  }),
});

export type AppRouter = typeof appRouter;
