import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

import { conversations, events, careerGoals, blogArticles, userSettings, financialRecords, goals, aiResources } from "../drizzle/schema";

/**
 * 会話履歴を保存
 */
export async function saveConversation(
  userId: number,
  role: "assistant" | "secretary" | "career" | "research",
  title: string,
  messages: unknown[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(conversations).values({
    userId,
    role,
    title,
    messages: JSON.stringify(messages),
  } as any);
}

/**
 * ユーザーの会話履歴を取得
 */
export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId));
}

/**
 * 予定を保存
 */
export async function saveEvent(
  userId: number,
  title: string,
  startTime: Date,
  description?: string,
  endTime?: Date,
  location?: string,
  type?: "meeting" | "date" | "travel" | "task" | "other"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(events).values({
    userId,
    title,
    startTime,
    endTime,
    description,
    location,
    type: type || "other",
  });
}

/**
 * ユーザーの予定を取得
 */
export async function getUserEvents(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(events)
    .where(eq(events.userId, userId));
}

/**
 * キャリア目標を保存
 */
export async function saveCareerGoal(
  userId: number,
  title: string,
  description?: string,
  targetDate?: Date,
  roadmap?: unknown[]
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(careerGoals).values({
    userId,
    title,
    description,
    targetDate,
    roadmap: JSON.stringify(roadmap || []),
  } as any);
}

/**
 * ブログ記事を保存
 */
export async function saveBlogArticle(
  userId: number,
  title: string,
  content?: string,
  prompt?: string,
  imageUrl?: string,
  status?: "draft" | "published" | "archived"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(blogArticles).values({
    userId,
    title,
    content,
    prompt,
    imageUrl,
    status: status || "draft",
  });
}

/**
 * ユーザー設定を取得
 */
export async function getUserSettings(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * ユーザー設定を保存
 */
export async function saveUserSettings(
  userId: number,
  llmApiUrl?: string,
  llmApiKey?: string,
  defaultRole?: "assistant" | "secretary" | "career" | "research"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getUserSettings(userId);
  if (existing) {
    return db
      .update(userSettings)
      .set({
        llmApiUrl,
        llmApiKey,
        defaultRole,
      })
      .where(eq(userSettings.userId, userId));
  }

  return db.insert(userSettings).values({
    userId,
    llmApiUrl,
    llmApiKey,
    defaultRole: defaultRole || "assistant",
  });
}

/**
 * 家計簿記録を保存
 */
export async function saveFinancialRecord(
  userId: number,
  type: "income" | "expense" | "investment" | "asset",
  amount: number,
  category?: string,
  description?: string,
  date?: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(financialRecords).values({
    userId,
    type,
    amount: amount.toString(),
    category,
    description,
    date: date || new Date(),
  } as any);
}

/**
 * 目標を保存
 */
export async function saveGoal(
  userId: number,
  title: string,
  description?: string,
  category?: string,
  targetDate?: Date,
  priority?: "low" | "medium" | "high"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(goals).values({
    userId,
    title,
    description,
    category,
    targetDate,
    priority: priority || "medium",
  });
}

/**
 * AI リソースを保存
 */
export async function saveAiResource(
  title: string,
  url: string,
  type: "news" | "paper" | "tool" | "tutorial",
  description?: string,
  source?: string,
  publishedAt?: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(aiResources).values({
    title,
    url,
    type,
    description,
    source,
    publishedAt,
  });
}

/**
 * 最新の AI リソースを取得
 */
export async function getLatestAiResources(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(aiResources)
    .orderBy((table) => table.createdAt)
    .limit(limit);
}
