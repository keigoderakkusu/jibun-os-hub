import { describe, it, expect } from "vitest";
import { z } from "zod";

describe("tRPC Routers", () => {
  describe("conversations router", () => {
    it("should validate conversation input schema", () => {
      const schema = z.object({
        role: z.enum(["assistant", "secretary", "career", "research"]),
        title: z.string(),
        messages: z.array(z.any()),
      });

      const validInput = {
        role: "assistant" as const,
        title: "Test Conversation",
        messages: [],
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });

    it("should reject invalid role", () => {
      const schema = z.object({
        role: z.enum(["assistant", "secretary", "career", "research"]),
        title: z.string(),
        messages: z.array(z.any()),
      });

      const invalidInput = {
        role: "invalid",
        title: "Test",
        messages: [],
      };

      expect(() => schema.parse(invalidInput)).toThrow();
    });
  });

  describe("events router", () => {
    it("should validate event input schema", () => {
      const schema = z.object({
        title: z.string(),
        startTime: z.date(),
        description: z.string().optional(),
        endTime: z.date().optional(),
        location: z.string().optional(),
        type: z.enum(["meeting", "date", "travel", "task", "other"]).optional(),
      });

      const validInput = {
        title: "Meeting",
        startTime: new Date(),
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });

    it("should accept optional event fields", () => {
      const schema = z.object({
        title: z.string(),
        startTime: z.date(),
        description: z.string().optional(),
        endTime: z.date().optional(),
        location: z.string().optional(),
        type: z.enum(["meeting", "date", "travel", "task", "other"]).optional(),
      });

      const validInput = {
        title: "Meeting",
        startTime: new Date(),
        description: "Team sync",
        location: "Conference Room A",
        type: "meeting" as const,
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });
  });

  describe("careerGoals router", () => {
    it("should validate career goal input schema", () => {
      const schema = z.object({
        title: z.string(),
        description: z.string().optional(),
        targetDate: z.date().optional(),
        roadmap: z.array(z.any()).optional(),
      });

      const validInput = {
        title: "Learn TypeScript",
        description: "Master TypeScript fundamentals",
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });
  });

  describe("blog router", () => {
    it("should validate blog article input schema", () => {
      const schema = z.object({
        title: z.string(),
        content: z.string().optional(),
        prompt: z.string().optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["draft", "published", "archived"]).optional(),
      });

      const validInput = {
        title: "My First Article",
        content: "Article content here...",
        status: "draft" as const,
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });
  });

  describe("settings router", () => {
    it("should validate settings input schema", () => {
      const schema = z.object({
        llmApiUrl: z.string().optional(),
        llmApiKey: z.string().optional(),
        defaultRole: z.enum(["assistant", "secretary", "career", "research"]).optional(),
      });

      const validInput = {
        llmApiUrl: "http://localhost:8080",
        llmApiKey: "test-key",
        defaultRole: "assistant" as const,
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });
  });

  describe("goals router", () => {
    it("should validate goal input schema", () => {
      const schema = z.object({
        title: z.string(),
        description: z.string().optional(),
        category: z.string().optional(),
        targetDate: z.date().optional(),
        priority: z.enum(["low", "medium", "high"]).optional(),
      });

      const validInput = {
        title: "Complete project",
        priority: "high" as const,
      };

      expect(() => schema.parse(validInput)).not.toThrow();
    });
  });
});
