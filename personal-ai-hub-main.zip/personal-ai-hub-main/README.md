# 🤖 Personal AI Hub

複数のAIエージェント役割を切り替えながら、日常業務や目標達成をサポートするWebアプリケーション。

**特徴**:
- ✨ 4つのAIエージェント役割（副業、秘書、キャリア、AI情報）
- 🚀 ローカルLLM（Bonsai 8B + llama.cpp）で完全プライベート実行
- 💰 完全無料・オープンソース
- 📱 マルチデバイス対応（PC・スマートフォン）
- 🗄️ MySQL データベース統合
- 🔐 Manus OAuth 認証

## 🎯 主な機能

### 1. マルチロールチャット
- **副業アシスタント**: 記事作成、ビジネスアドバイス、動画企画
- **秘書・予定管理**: 予定表示、デートプラン、旅行プラン提案
- **キャリアエージェント**: スキル習得ロードマップ、学習計画
- **AI情報収集**: 最新のAI技術、論文、ツール情報

### 2. ダッシュボード
- 統計情報（今日の予定、進行中のプロジェクト、スキル進度）
- 最新AIニュースフィード
- 予定表示
- ユーザー設定管理

### 3. データ管理
- 会話履歴の保存・検索
- 予定・イベント管理
- キャリア目標・ロードマップ
- ブログ記事生成・管理
- 家計簿・資産管理
- 目標達成ツール

## 🛠️ 技術スタック

| レイヤー | 技術 |
|---------|------|
| **フロントエンド** | React 19 + Tailwind CSS 4 + shadcn/ui |
| **バックエンド** | Express 4 + tRPC 11 |
| **データベース** | MySQL + Drizzle ORM |
| **LLM** | llama.cpp (Bonsai 8B) |
| **認証** | Manus OAuth |
| **ストレージ** | S3 (Manus) |

## 📦 インストール

### 前提条件
- Node.js v18+
- pnpm または npm
- MySQL 8.0+（または Docker）
- llama.cpp + Bonsai 8B GGUF

### クイックスタート

```bash
# 1. リポジトリをクローン
git clone https://github.com/keigode/keigoderakkusu.git
cd keigoderakkusu

# 2. 依存関係をインストール
pnpm install

# 3. 環境変数を設定
cp .env.example .env.local
# .env.local を編集

# 4. データベースをセットアップ
pnpm drizzle-kit generate
pnpm drizzle-kit migrate

# 5. 開発サーバーを起動
pnpm dev
```

詳細は [SETUP_WINDOWS.md](./SETUP_WINDOWS.md) を参照してください。

## 🚀 使用方法

### ホームページ
```
http://localhost:3000
```
ランディングページが表示されます。ログインボタンをクリック。

### ダッシュボード
```
http://localhost:3000/dashboard
```
ログイン後、自動的にダッシュボードに遷移します。

### チャット機能
1. ダッシュボードの左サイドバーから役割を選択
2. チャットタブでメッセージを入力
3. llama.cpp が応答

## 📁 プロジェクト構造

```
personal-ai-hub/
├── client/                      # React フロントエンド
│   ├── src/
│   │   ├── pages/              # ページコンポーネント
│   │   │   ├── Home.tsx        # ランディングページ
│   │   │   ├── Dashboard.tsx   # ダッシュボード
│   │   │   └── NotFound.tsx
│   │   ├── components/         # UI コンポーネント
│   │   │   ├── MultiRoleLayout.tsx    # ダッシュボードレイアウト
│   │   │   ├── ChatInterface.tsx      # チャットUI
│   │   │   └── ui/             # shadcn/ui コンポーネント
│   │   ├── App.tsx             # ルート定義
│   │   ├── main.tsx            # エントリーポイント
│   │   ├── index.css           # グローバルスタイル
│   │   └── lib/trpc.ts         # tRPC クライアント
│   ├── index.html
│   └── package.json
├── server/                      # Express バックエンド
│   ├── routers.ts              # tRPC ルーター定義
│   ├── db.ts                   # データベースクエリ
│   ├── auth.logout.test.ts     # テスト例
│   ├── routers.test.ts         # tRPC テスト
│   └── _core/                  # フレームワークコア
│       ├── index.ts            # Express サーバー
│       ├── context.ts          # tRPC コンテキスト
│       ├── trpc.ts             # tRPC セットアップ
│       ├── cookies.ts          # Cookie 管理
│       ├── oauth.ts            # OAuth ハンドラ
│       ├── llm.ts              # LLM 統合
│       └── env.ts              # 環境変数
├── drizzle/                     # データベーススキーマ
│   ├── schema.ts               # テーブル定義
│   └── migrations/             # マイグレーション SQL
├── shared/                      # 共有定数・型
│   └── const.ts
├── storage/                     # S3 ストレージ
│   └── index.ts
├── package.json
├── tsconfig.json
├── vite.config.ts
├── SETUP_WINDOWS.md            # Windows セットアップガイド
└── README.md                   # このファイル
```

## 🗄️ データベーススキーマ

### テーブル一覧

| テーブル | 用途 |
|---------|------|
| `users` | ユーザー情報 |
| `conversations` | チャット履歴（役割ごと） |
| `events` | 予定・イベント |
| `careerGoals` | キャリア目標・ロードマップ |
| `blogArticles` | ブログ記事 |
| `financialRecords` | 家計簿・資産管理 |
| `goals` | 目標達成 |
| `aiResources` | AIニュース・リソース |
| `userSettings` | ユーザー設定（LLM接続） |

詳細は `drizzle/schema.ts` を参照。

## 🧪 テスト

```bash
# ユニットテストを実行
pnpm test

# テストを監視モードで実行
pnpm test:watch

# カバレッジレポートを生成
pnpm test:coverage
```

## 🔌 LLM 統合

### llama.cpp との接続

アプリケーションは OpenAI 互換 API 経由で llama.cpp に接続します。

```typescript
// server/routers.ts の例
const response = await invokeLLM({
  messages: [
    { role: "system", content: "You are a helpful assistant." },
    { role: "user", content: "Hello!" },
  ],
});
```

### Bonsai 8B の特徴

- **1-bit アーキテクチャ**: わずか 1.15GB のメモリで 8B パラメータを実行
- **高速推論**: CPU で 2-8 トークン/秒（GPU で 131 トークン/秒）
- **完全オープンソース**: MIT ライセンス

詳細: [Bonsai GitHub](https://github.com/prism-ml/Bonsai)

## 🚀 デプロイ

### Vercel へのデプロイ

```bash
npm install -g vercel
vercel
```

### Railway へのデプロイ

1. [Railway](https://railway.app) にサインアップ
2. GitHub リポジトリを接続
3. 環境変数を設定
4. デプロイ

### Docker でのデプロイ

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN pnpm install
RUN pnpm build
CMD ["pnpm", "start"]
```

## 📝 環境変数

```env
# Database
DATABASE_URL=mysql://user:password@localhost:3306/personal_ai_hub

# Authentication
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/login

# JWT
JWT_SECRET=your-secret-key

# LLM
LLM_API_URL=http://localhost:8080
LLM_API_KEY=dummy

# Owner
OWNER_OPEN_ID=your-open-id
OWNER_NAME=Your Name
```

## 🔒 セキュリティ

- ✅ HTTPS 推奨（本番環境）
- ✅ JWT トークン認証
- ✅ CORS 設定
- ✅ SQL インジェクション対策（Drizzle ORM）
- ✅ XSS 対策（React）
- ✅ CSRF トークン（Cookie）

## 📚 ドキュメント

- [tRPC ドキュメント](https://trpc.io)
- [Drizzle ORM ドキュメント](https://orm.drizzle.team)
- [React ドキュメント](https://react.dev)
- [Tailwind CSS ドキュメント](https://tailwindcss.com)
- [llama.cpp ドキュメント](https://github.com/ggerganov/llama.cpp)

## 🤝 貢献

プルリクエストを歓迎します！

1. Fork してください
2. フィーチャーブランチを作成（`git checkout -b feature/amazing-feature`）
3. コミット（`git commit -m 'Add amazing feature'`）
4. プッシュ（`git push origin feature/amazing-feature`）
5. プルリクエストを作成

## 📄 ライセンス

MIT License - 詳細は [LICENSE](./LICENSE) を参照

## 💬 サポート

問題が発生した場合：

1. [GitHub Issues](https://github.com/keigode/keigoderakkusu/issues) を確認
2. [SETUP_WINDOWS.md](./SETUP_WINDOWS.md) のトラブルシューティングを参照
3. ログファイルを確認（`.manus-logs/`）

## 🎯 ロードマップ

- [ ] 音声入力機能（Whisper API）
- [ ] 画像生成機能（DALL-E / Stable Diffusion）
- [ ] ニュース自動収集（RSS フィード）
- [ ] モバイルアプリ（React Native）
- [ ] クラウド同期（複数デバイス対応）
- [ ] プラグインシステム
- [ ] 高度な分析・レポート生成

## 👨‍💻 開発者

**keigode** - [GitHub](https://github.com/keigode)

## 🙏 謝辞

- [Bonsai 1-bit LLM](https://github.com/prism-ml/Bonsai) チーム
- [llama.cpp](https://github.com/ggerganov/llama.cpp) コミュニティ
- [tRPC](https://trpc.io) チーム
- [shadcn/ui](https://ui.shadcn.com) コンポーネント

---

**Happy coding! 🚀**

Made with ❤️ for AI enthusiasts
