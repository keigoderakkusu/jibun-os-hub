import { useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Loader2, Zap, MessageSquare, Calendar, TrendingUp } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // ログイン済みならダッシュボードにリダイレクト
  useEffect(() => {
    if (isAuthenticated && !loading) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, loading, setLocation]);

  // ローディング中
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="text-center">
          <Loader2 className="animate-spin mx-auto mb-4" size={40} />
          <p className="text-white">読み込み中...</p>
        </div>
      </div>
    );
  }

  // ログイン前のランディングページ
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="text-blue-500" size={28} />
            <h1 className="text-2xl font-bold text-white">Personal AI Hub</h1>
          </div>
          <Button onClick={() => (window.location.href = getLoginUrl())} size="lg">
            ログイン
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-6">
            複数のAIエージェントで、日々の業務を加速
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            副業アシスタント、秘書、キャリアエージェント、AI情報収集。
            4つの役割を切り替えながら、あなたの目標達成をサポートします。
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6"
          >
            今すぐ始める
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
          {/* Feature 1: Chat */}
          <Card className="bg-slate-800 border-slate-700 p-6 hover:border-blue-500 transition">
            <MessageSquare className="text-blue-500 mb-4" size={32} />
            <h3 className="text-lg font-semibold text-white mb-2">マルチロールチャット</h3>
            <p className="text-slate-400">
              4つのAIエージェント役割を自由に切り替え。それぞれの専門知識でサポート
            </p>
          </Card>

          {/* Feature 2: Schedule */}
          <Card className="bg-slate-800 border-slate-700 p-6 hover:border-purple-500 transition">
            <Calendar className="text-purple-500 mb-4" size={32} />
            <h3 className="text-lg font-semibold text-white mb-2">予定・プラン管理</h3>
            <p className="text-slate-400">
              デート、旅行、ビジネス会議。すべての予定をAIが最適に提案
            </p>
          </Card>

          {/* Feature 3: Career */}
          <Card className="bg-slate-800 border-slate-700 p-6 hover:border-green-500 transition">
            <TrendingUp className="text-green-500 mb-4" size={32} />
            <h3 className="text-lg font-semibold text-white mb-2">キャリア支援</h3>
            <p className="text-slate-400">
              スキル習得ロードマップ、学習計画。あなたの成長を加速
            </p>
          </Card>

          {/* Feature 4: News */}
          <Card className="bg-slate-800 border-slate-700 p-6 hover:border-orange-500 transition">
            <Zap className="text-orange-500 mb-4" size={32} />
            <h3 className="text-lg font-semibold text-white mb-2">AI情報収集</h3>
            <p className="text-slate-400">
              最新のAI技術、論文、ツール。自動で収集・ダッシュボードに表示
            </p>
          </Card>
        </div>

        {/* Benefits Section */}
        <section className="mt-20 bg-slate-800 rounded-lg p-12 border border-slate-700">
          <h3 className="text-3xl font-bold text-white mb-8 text-center">
            なぜ Personal AI Hub？
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-xl font-semibold text-blue-400 mb-3">🚀 高速実行</h4>
              <p className="text-slate-300">
                ローカルLLM（Bonsai 8B）で、プライベートで高速な推論。インターネット接続不要
              </p>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-purple-400 mb-3">🔒 プライベート</h4>
              <p className="text-slate-300">
                すべてのデータはあなたの環境に保存。外部サーバーに送信されません
              </p>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-green-400 mb-3">💰 無料</h4>
              <p className="text-slate-300">
                完全オープンソース。追加費用なし。Windows 8GB RAMで動作
              </p>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="mt-20 text-center">
          <h3 className="text-3xl font-bold text-white mb-6">
            準備はいいですか？
          </h3>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8 py-6"
          >
            ログインして始める
          </Button>
        </section>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-20 py-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-slate-400">
          <p>Personal AI Hub © 2026 - Powered by Bonsai 8B + llama.cpp</p>
        </div>
      </footer>
    </div>
  );
}
