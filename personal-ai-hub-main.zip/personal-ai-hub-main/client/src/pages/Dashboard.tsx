import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Zap, TrendingUp, BookOpen } from "lucide-react";
import MultiRoleLayout from "@/components/MultiRoleLayout";
import ChatInterface from "@/components/ChatInterface";
import { trpc } from "@/lib/trpc";

type Role = "assistant" | "secretary" | "career" | "research";

export default function Dashboard() {
  const [activeRole, setActiveRole] = useState<Role>("assistant");
  const [activeTab, setActiveTab] = useState("chat");

  // データ取得
  const { data: events } = trpc.events.list.useQuery();
  const { data: aiResources } = trpc.aiResources.latest.useQuery({ limit: 5 });
  const { data: settings } = trpc.settings.get.useQuery();

  return (
    <MultiRoleLayout>
      <div className="space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">今日の予定</p>
                  <p className="text-2xl font-bold">{events?.length || 0}</p>
                </div>
                <Calendar className="text-blue-500" size={32} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">進行中のプロジェクト</p>
                  <p className="text-2xl font-bold">3</p>
                </div>
                <Zap className="text-orange-500" size={32} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">スキル習得進度</p>
                  <p className="text-2xl font-bold">65%</p>
                </div>
                <TrendingUp className="text-green-500" size={32} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">新着AI情報</p>
                  <p className="text-2xl font-bold">{aiResources?.length || 0}</p>
                </div>
                <BookOpen className="text-purple-500" size={32} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="chat">チャット</TabsTrigger>
            <TabsTrigger value="schedule">予定</TabsTrigger>
            <TabsTrigger value="news">AIニュース</TabsTrigger>
            <TabsTrigger value="settings">設定</TabsTrigger>
          </TabsList>

          {/* Chat Tab */}
          <TabsContent value="chat" className="h-[600px]">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>AIエージェントとの対話</CardTitle>
              </CardHeader>
              <CardContent className="h-[calc(100%-80px)]">
                <ChatInterface role={activeRole} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle>予定管理</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {events && events.length > 0 ? (
                    events.map((event) => (
                      <div key={event.id} className="border-l-4 border-blue-500 pl-4 py-2">
                        <p className="font-semibold">{event.title}</p>
                        <p className="text-sm text-slate-600">
                          {new Date(event.startTime).toLocaleString()}
                        </p>
                        {event.description && (
                          <p className="text-sm text-slate-700 mt-1">{event.description}</p>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-500">予定がありません</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI News Tab */}
          <TabsContent value="news">
            <Card>
              <CardHeader>
                <CardTitle>最新AI情報</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiResources && aiResources.length > 0 ? (
                    aiResources.map((resource) => (
                      <a
                        key={resource.id}
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block border rounded-lg p-4 hover:bg-slate-50 transition"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-semibold text-blue-600 hover:underline">
                              {resource.title}
                            </p>
                            <p className="text-sm text-slate-600 mt-1">{resource.description}</p>
                            <div className="flex gap-2 mt-2">
                              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                {resource.type}
                              </span>
                              {resource.source && (
                                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded">
                                  {resource.source}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </a>
                    ))
                  ) : (
                    <p className="text-slate-500">情報がありません</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>設定</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      LLM API URL
                    </label>
                    <input
                      type="text"
                      defaultValue={settings?.llmApiUrl || ""}
                      placeholder="http://localhost:8080"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      API キー
                    </label>
                    <input
                      type="password"
                      defaultValue={settings?.llmApiKey || ""}
                      placeholder="API キーを入力"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <Button className="w-full">設定を保存</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MultiRoleLayout>
  );
}
