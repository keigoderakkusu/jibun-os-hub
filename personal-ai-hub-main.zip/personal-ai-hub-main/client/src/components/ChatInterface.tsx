import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Loader2, Mic } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";

type Role = "assistant" | "secretary" | "career" | "research";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface ChatInterfaceProps {
  role: Role;
  conversationId?: number;
}

const ROLE_PROMPTS: Record<Role, string> = {
  assistant:
    "あなたは副業アシスタントです。ブログ記事の作成、ビジネスアドバイス、動画企画などをサポートします。",
  secretary:
    "あなたは秘書です。予定管理、デートプラン、旅行プランを提案します。ユーザーのライフスタイルを豊かにすることが目標です。",
  career:
    "あなたはキャリアエージェントです。スキル習得、キャリア開発、学習ロードマップの提案をします。ユーザーの成長を支援します。",
  research:
    "あなたはAI情報収集エージェントです。最新のAI技術、論文、ツール、トレンドについて情報提供します。",
};

export default function ChatInterface({ role, conversationId }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const saveConversationMutation = trpc.conversations.save.useMutation();

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // TODO: LLM API に接続してレスポンスを取得
      // 現在はダミーレスポンス
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `[${role}] ご質問ありがとうございます。LLM統合準備中です。\n\nあなたのメッセージ: "${input}"`,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // 会話を保存
      await saveConversationMutation.mutateAsync({
        role,
        title: `${role} - ${new Date().toLocaleString()}`,
        messages: [...messages, userMessage, assistantMessage],
      });
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      alert("お使いのブラウザは音声入力に対応していません");
      return;
    }

    try {
      setIsRecording(!isRecording);
      // TODO: 音声録音・テキスト化実装
      if (isRecording) {
        // 停止処理
      } else {
        // 開始処理
      }
    } catch (error) {
      console.error("Voice input error:", error);
    }
  };

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Messages Area */}
      <Card className="flex-1 flex flex-col overflow-hidden">
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-center text-slate-500">
                <div>
                  <p className="text-lg font-semibold mb-2">会話を開始しましょう</p>
                  <p className="text-sm">何かお手伝いできることはありますか？</p>
                </div>
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      msg.role === "user"
                        ? "bg-blue-500 text-white rounded-br-none"
                        : "bg-slate-100 text-slate-900 rounded-bl-none"
                    }`}
                  >
                    {msg.role === "assistant" ? (
                      <Streamdown>{msg.content}</Streamdown>
                    ) : (
                      <p>{msg.content}</p>
                    )}
                    <p className="text-xs opacity-70 mt-1">
                      {msg.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-100 text-slate-900 px-4 py-2 rounded-lg rounded-bl-none">
                  <Loader2 className="animate-spin" size={20} />
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>
      </Card>

      {/* Input Area */}
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === "Enter" && !isLoading) {
              handleSendMessage();
            }
          }}
          placeholder="メッセージを入力..."
          disabled={isLoading}
          className="flex-1"
        />
        <Button
          onClick={handleVoiceInput}
          variant="outline"
          size="icon"
          disabled={isLoading}
          className={isRecording ? "bg-red-100 text-red-600" : ""}
        >
          <Mic size={20} />
        </Button>
        <Button
          onClick={handleSendMessage}
          disabled={isLoading || !input.trim()}
          size="icon"
        >
          {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
        </Button>
      </div>
    </div>
  );
}
