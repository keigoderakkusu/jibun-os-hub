import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { LogOut, Settings, Menu, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

type Role = "assistant" | "secretary" | "career" | "research";

interface MultiRoleLayoutProps {
  children?: React.ReactNode;
}

const ROLE_CONFIG: Record<Role, { label: string; description: string; icon: string; color: string }> = {
  assistant: {
    label: "副業アシスタント",
    description: "記事作成やアドバイス、動画作成",
    icon: "💼",
    color: "from-blue-500 to-blue-600",
  },
  secretary: {
    label: "秘書・予定管理",
    description: "予定やデート旅プランを考える",
    icon: "📅",
    color: "from-purple-500 to-purple-600",
  },
  career: {
    label: "キャリアエージェント",
    description: "スキル習得と日々のキャリア支援",
    icon: "🚀",
    color: "from-green-500 to-green-600",
  },
  research: {
    label: "AI情報収集",
    description: "最新のAI情報を自動収集",
    icon: "🔬",
    color: "from-orange-500 to-orange-600",
  },
};

export default function MultiRoleLayout({ children }: MultiRoleLayoutProps) {
  const { user, logout, isAuthenticated } = useAuth();
  const [currentRole, setCurrentRole] = useState<Role>("assistant");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <Card className="p-8 max-w-md w-full">
          <h1 className="text-3xl font-bold mb-4 text-center">Personal AI Hub</h1>
          <p className="text-gray-600 text-center mb-6">
            複数のAIエージェント役割を切り替えながら、日常業務や目標達成をサポート
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full"
            size="lg"
          >
            ログイン
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-white border-r border-slate-200 transition-all duration-300 flex flex-col`}
      >
        {/* Logo */}
        <div className="p-4 border-b border-slate-200">
          <div className="flex items-center justify-between">
            {sidebarOpen && <h2 className="font-bold text-lg">AI Hub</h2>}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1 hover:bg-slate-100 rounded"
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Role Navigation */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {(Object.entries(ROLE_CONFIG) as Array<[Role, typeof ROLE_CONFIG[Role]]>).map(
            ([role, config]) => (
              <button
                key={role}
                onClick={() => setCurrentRole(role)}
                className={`w-full p-3 rounded-lg text-left transition-all ${
                  currentRole === role
                    ? `bg-gradient-to-r ${config.color} text-white shadow-lg`
                    : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                }`}
              >
                <div className="text-2xl mb-1">{config.icon}</div>
                {sidebarOpen && (
                  <>
                    <div className="font-semibold text-sm">{config.label}</div>
                    <div className="text-xs opacity-75">{config.description}</div>
                  </>
                )}
              </button>
            )
          )}
        </div>

        {/* User Profile */}
        <div className="border-t border-slate-200 p-4 space-y-2">
          {sidebarOpen && (
            <div className="text-sm font-medium text-slate-700 truncate">{user?.name}</div>
          )}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={() => (window.location.href = "/settings")}
            >
              <Settings size={16} />
              {sidebarOpen && "設定"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={logout}
            >
              <LogOut size={16} />
              {sidebarOpen && "ログアウト"}
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                {ROLE_CONFIG[currentRole].label}
              </h1>
              <p className="text-sm text-slate-600">
                {ROLE_CONFIG[currentRole].description}
              </p>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            {children || (
              <div className="text-center text-slate-500">
                <p className="text-lg">コンテンツを選択してください</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
