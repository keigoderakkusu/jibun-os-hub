# Personal AI Hub - Windows 11 セットアップガイド

このガイドでは、Windows 11（RAM 8GB）上で Personal AI Hub を llama.cpp + Bonsai 8B と共に実行する手順を説明します。

## 📋 前提条件

- **OS**: Windows 11
- **RAM**: 8GB 以上
- **ディスク**: 10GB 以上の空き容量
- **Node.js**: v18 以上
- **Git**: インストール済み

## 🚀 ステップ 1: リポジトリをクローン

```bash
git clone https://github.com/keigode/keigoderakkusu.git
cd keigoderakkusu
```

## 📦 ステップ 2: 依存関係をインストール

```bash
# Node.js 依存関係
pnpm install

# または npm を使用
npm install
```

## 🗄️ ステップ 3: MySQL データベースをセットアップ

Personal AI Hub はデータベースが必要です。以下のいずれかを選択してください：

### オプション A: Docker で MySQL を実行（推奨）

```bash
# Docker Desktop をインストール（https://www.docker.com/products/docker-desktop）

# MySQL コンテナを起動
docker run --name personal-ai-hub-mysql -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=personal_ai_hub -p 3306:3306 -d mysql:8.0

# 接続確認
mysql -h 127.0.0.1 -u root -proot -D personal_ai_hub
```

### オプション B: ローカル MySQL をインストール

1. [MySQL Community Server](https://dev.mysql.com/downloads/mysql/) をダウンロード・インストール
2. MySQL Workbench で新しいデータベース `personal_ai_hub` を作成

## ⚙️ ステップ 4: 環境変数を設定

`.env.local` ファイルを作成し、以下の内容を追加：

```env
# Database
DATABASE_URL=mysql://root:root@localhost:3306/personal_ai_hub

# Authentication (Manus OAuth - 本番環境用)
# 開発環境ではダミー値を使用
VITE_APP_ID=dev-app-id
OAUTH_SERVER_URL=http://localhost:3000
VITE_OAUTH_PORTAL_URL=http://localhost:3000/login

# JWT Secret
JWT_SECRET=your-secret-key-here-change-in-production

# LLM Configuration
LLM_API_URL=http://localhost:8080
LLM_API_KEY=dummy

# Owner Info
OWNER_OPEN_ID=dev-user
OWNER_NAME=Developer
```

## 🦙 ステップ 5: llama.cpp + Bonsai 8B をセットアップ

### 5.1 llama.cpp をダウンロード

1. [llama.cpp Releases](https://github.com/ggerganov/llama.cpp/releases) にアクセス
2. `llama-b****-bin-win-cpu-x64.zip` をダウンロード
3. 任意のフォルダに解凍（例：`C:\llama-cpp`）

### 5.2 Bonsai 8B GGUF をダウンロード

1. [HuggingFace - prism-ml/Bonsai-8B-gguf](https://huggingface.co/prism-ml/Bonsai-8B-gguf) にアクセス
2. `Bonsai-8B-Q4_K_M.gguf`（約5GB）をダウンロード
3. llama.cpp フォルダ内に配置

### 5.3 llama.cpp サーバーを起動

PowerShell を開き、以下を実行：

```powershell
cd C:\llama-cpp
.\llama-server.exe -m Bonsai-8B-Q4_K_M.gguf --port 8080 -c 4096 -n 512
```

**出力例**:
```
ggml_cuda_init: GGML_CUDA_FORCE_MMQ not set, using ggml_cuda_can_mul_mat to detect
llama_model_load: loaded model from Bonsai-8B-Q4_K_M.gguf
llama_new_context_with_model: n_ctx = 4096, n_batch = 512
server: listening on http://0.0.0.0:8080
```

## 🗄️ ステップ 6: データベーススキーマを初期化

別の PowerShell ウィンドウで：

```bash
cd keigoderakkusu
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

## 🎯 ステップ 7: アプリケーションを起動

```bash
# 開発サーバーを起動
pnpm dev
```

**出力例**:
```
Server running on http://localhost:3000/
```

## 🌐 ステップ 8: ブラウザでアクセス

ブラウザを開き、以下にアクセス：

```
http://localhost:3000
```

## 📝 使用方法

### ホームページ
- ログイン前のランディングページが表示されます
- 「今すぐ始める」をクリック

### ダッシュボード
- ログイン後、自動的にダッシュボード（`/dashboard`）に遷移
- 4つの役割タブを切り替え可能：
  - **副業アシスタント**: 記事作成、ビジネスアドバイス
  - **秘書・予定管理**: 予定、デートプラン、旅行プラン
  - **キャリアエージェント**: スキル習得、キャリア開発
  - **AI情報収集**: 最新のAI技術情報

### チャット機能
- 各役割でチャットを開始
- メッセージを入力して送信
- llama.cpp が OpenAI 互換 API を通じて応答

## 🔧 トラブルシューティング

### llama.cpp が起動しない
```bash
# CUDA が利用可能か確認
nvidia-smi

# CPU のみで実行（遅い）
.\llama-server.exe -m Bonsai-8B-Q4_K_M.gguf --port 8080 -c 2048
```

### データベース接続エラー
```bash
# MySQL が起動しているか確認
mysql -h 127.0.0.1 -u root -proot

# Docker コンテナを確認
docker ps
```

### ポート 3000 が既に使用されている
```bash
# 別のポートで起動
PORT=3001 pnpm dev
```

### メモリ不足エラー
```bash
# コンテキストサイズを削減
.\llama-server.exe -m Bonsai-8B-Q4_K_M.gguf --port 8080 -c 2048
```

## 📚 プロジェクト構造

```
keigoderakkusu/
├── client/                 # React フロントエンド
│   ├── src/
│   │   ├── pages/         # ページコンポーネント
│   │   ├── components/    # UI コンポーネント
│   │   ├── App.tsx        # ルート定義
│   │   └── main.tsx       # エントリーポイント
│   └── index.html
├── server/                 # Express バックエンド
│   ├── routers.ts         # tRPC ルーター定義
│   ├── db.ts              # データベースクエリ
│   └── _core/             # フレームワークコア
├── drizzle/               # データベーススキーマ
│   └── schema.ts
├── shared/                # 共有定数・型
├── package.json
└── README.md
```

## 🚀 本番環境へのデプロイ

### Vercel へのデプロイ
```bash
npm install -g vercel
vercel
```

### Railway へのデプロイ
1. [Railway](https://railway.app) にサインアップ
2. GitHub リポジトリを接続
3. 環境変数を設定
4. デプロイ

## 📖 詳細ドキュメント

- [tRPC ドキュメント](https://trpc.io)
- [Drizzle ORM ドキュメント](https://orm.drizzle.team)
- [llama.cpp ドキュメント](https://github.com/ggerganov/llama.cpp)
- [Bonsai 1-bit LLM](https://github.com/prism-ml/Bonsai)

## 💡 次のステップ

1. **llama.cpp との統合テスト** - チャット機能を試す
2. **カスタマイズ** - 役割プロンプトを編集
3. **拡張機能** - 音声入力、画像生成を追加
4. **デプロイ** - 本番環境に公開

## ❓ サポート

問題が発生した場合：

1. [GitHub Issues](https://github.com/keigode/keigoderakkusu/issues) を確認
2. ログファイルを確認（`.manus-logs/`）
3. llama.cpp のコンソール出力を確認

---

**Happy coding! 🎉**
